
// import React, { useState } from 'react';
// import Header from './components/Header';
// import Search from './components/Search';
// import Filter from './components/Filter';
// import Country from './components/Country';
// import countries from './data.json';
// import OneCountry from './components/OneCountry';
// import { BrowserRouter, Route, Routes } from 'react-router-dom';

// function App() {
//   const [region, setRegion] = useState(''); 
//   const [search, setSearch] = useState('');

//   const filteredCountries = countries.filter(
//     (country) =>
//       country.name.toLowerCase().includes(search.toLowerCase()) &&
//       (region ? country.region === region : true) 
//   );

//   return (
//     <>
//     <Header />
//     <BrowserRouter>
//       <Routes>
//         <Route  path='/' element={
    
//               <div className="p-6 dark:bg-DarkModeBackground min-h-svh">
//                 <div className="flex flex-col md:flex-row justify-between items-center mr-6 lg:flex-row xl:flex-row">
//                   <Search setSearch={setSearch} />
//                   <Filter setRegion={setRegion} country={filteredCountries}  />
//                 </div>
//                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
//                   {filteredCountries.map((country) => (
//                     <Country key={country.name} country={country} />
//                   ))}
//                 </div>
        
//               </div>}
//               />
          
//               <Route path="/country/:countryName" element={<OneCountry/>} />
//       </Routes>
      
//         </BrowserRouter>
//     </>
//   );
// }

// export default App;

import React, { useEffect, useState } from 'react';
import Header from './components/Header';



function App() {
  const API_URL ='https://restcountries.com/v3.1/all'

  const [country,setCountry] = useState([])
  const [error,setError] = useState('')

  useEffect(()=>{
    const fetchItems = async()=>{
      try {
        const fetchResponse = await fetch (API_URL)
        if(! fetchResponse.ok) throw Error ('Data not received')
        const data = await fetchResponse.json()
        setCountry(data)
        setError(null)
        console.log(data)
      }
      catch(err){
        setError(err.message)
      }
    }
    (async()=> await fetchItems())()
  },[])


  return(
    <div>
      <Header/>
      <div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6'>
          {error && <div className="error">{error}</div>}
          {country.map((countries)=>(
            <div key={countries.name.common}>
              {countries.flags.png}
              <p>{countries.name}</p>
              <p>{countries.population}</p>
              <p>{countries.region}</p>
              <p>{countries.capital}</p>
            </div>
          ))}


      </div>
    </div>
  )
}
export default App;